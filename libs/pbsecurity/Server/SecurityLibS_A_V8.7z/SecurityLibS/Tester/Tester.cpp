// Tester.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include <ClientServerVerify.h>
#include <ClientServerVerify4Svr.h>
//#include <ModuleCrossVerify.h>

#ifdef _DEBUG
#pragma comment(lib, "SecurityLib_A1D")
#else
#pragma comment(lib, "SecurityLib_A1")
#endif

using namespace std;

struct Order
{
	double dblPrice;
	int nVolume;
};

void ShowHEXofBytes(const unsigned char* szBuffer, size_t uBufferSize)
{
	size_t uCharBufferSize = (uBufferSize * 2) + 1;
	char* pszCharBuffer = new char[uCharBufferSize];
	for (size_t i = 0; i < uBufferSize; ++i)
	{
		int nBytes = szBuffer[i];
#if _MSC_VER > 1600
		sprintf_s(pszCharBuffer + i * 2, uCharBufferSize - i * 2, "%02X", nBytes);
#else
		sprintf(pszCharBuffer + i * 2, "%02X", nBytes);
#endif
	}
	pszCharBuffer[uCharBufferSize - 1] = 0;
	cout << pszCharBuffer << endl;
	delete[] pszCharBuffer;
}


void Magic(Order& order, int nVolume)
{
	order.nVolume = nVolume * 100;
}


int _tmain(int argc, _TCHAR* argv[])
{
	std::cout.imbue(locale(locale(), "", LC_CTYPE));

	//-----------------------------------------------------------------------------------
	//	���´��빩�ͻ����ύ��֤��Ϣʱ�ο�
	size_t uResultSize;
	unsigned char* pszBuffer = NULL;
	unsigned char szRandom[8] = { '1', '2', '3', '4', '5', '6', '7', '8' };
	{
		Pobo::Security::GetResultA(NULL, uResultSize, 0, 60, false);
		pszBuffer = new unsigned char[uResultSize];
		Pobo::Security::GetResultA(pszBuffer, uResultSize, 0, 60, false);
		Pobo::Security::ChangeAWithR(szRandom, sizeof(szRandom), pszBuffer, uResultSize);
		cout << "�ͻ�������ֵ������ʱ��棩: ";
		ShowHEXofBytes(pszBuffer, uResultSize);

		//	�������UTCʱ���
		//	�����Ա���ʱ�����ע�����д���
		delete[] pszBuffer;
		Pobo::Security::GetResultA(NULL, uResultSize, 0, 60, true);
		pszBuffer = new unsigned char[uResultSize];
		Pobo::Security::GetResultA(pszBuffer, uResultSize, 0, 60, true);
		Pobo::Security::ChangeAWithR(szRandom, sizeof(szRandom), pszBuffer, uResultSize);
		cout << "�ͻ�������ֵ��UTCʱ��棩: ";
		ShowHEXofBytes(pszBuffer, uResultSize);
		//-----------------------------------------------------------------------------------
	}
	cout << endl;
	::Sleep(500);

	//-----------------------------------------------------------------------------------
	//	���´��빩�������֤ʱ�ο�
	{
		bool bServerChecked = false;

		//	��ȡ��ԿA
		//	�ڷ����ʹ���趨����ԿA�����Ǿ�̬���ڲ�����ԿA��������֤
		char szLocalSecret[] = "rj5R9fnqpPGLaVZ8ic2iXttRe31zqVEF";
		unsigned char* pszKey = reinterpret_cast<unsigned char*>(szLocalSecret);
		size_t uKeySize = sizeof(szLocalSecret) - 1;
		int nModel = 1;

		/////////////////////////////////////////////////////////////////////////////////////////
		//	����ʱ���
		//	����
		if (Pobo::Security::Server::CheckResultAWithR(nModel, pszKey, uKeySize, szRandom, sizeof(szRandom), pszBuffer, uResultSize, 0, 60, false))
		{
			bServerChecked = true;
			cout << "����ʱ������У��ͨ��" << endl;
		}

		//	��1����
		if (Pobo::Security::Server::CheckResultAWithR(nModel, pszKey, uKeySize, szRandom, sizeof(szRandom), pszBuffer, uResultSize, -1, 60, false))
		{
			bServerChecked = true;
			cout << "����ʱ�为1����У��ͨ��" << endl;
		}

		//	��1����
		if (Pobo::Security::Server::CheckResultAWithR(nModel, pszKey, uKeySize, szRandom, sizeof(szRandom), pszBuffer, uResultSize, 1, 60, false))
		{
			bServerChecked = true;
			cout << "����ʱ����1����У��ͨ��" << endl;
		}
		/////////////////////////////////////////////////////////////////////////////////////////

		/////////////////////////////////////////////////////////////////////////////////////////
		//	UTCʱ���
		//	����
		if (Pobo::Security::Server::CheckResultAWithR(nModel, pszKey, uKeySize, szRandom, sizeof(szRandom), pszBuffer, uResultSize, 0, 60, true))
		{
			bServerChecked = true;
			cout << "UTCʱ������У��ͨ��" << endl;
		}

		//	��1����
		if (Pobo::Security::Server::CheckResultAWithR(nModel, pszKey, uKeySize, szRandom, sizeof(szRandom), pszBuffer, uResultSize, -1, 60, true))
		{
			bServerChecked = true;
			cout << "UTCʱ�为1����У��ͨ��" << endl;
		}

		//	��1����
		if (Pobo::Security::Server::CheckResultAWithR(nModel, pszKey, uKeySize, szRandom, sizeof(szRandom), pszBuffer, uResultSize, 1, 60, true))
		{
			bServerChecked = true;
			cout << "UTCʱ����1����У��ͨ��" << endl;
		}
		/////////////////////////////////////////////////////////////////////////////////////////

		//	�ȶԽ��
		cout << endl;
		cout << "�ͻ���" << (bServerChecked ? "" : "��") << "�Ϸ�" << endl;
		//-----------------------------------------------------------------------------------

		delete[] pszBuffer;
	}
	cout << endl;
//	return 0;
	
	//	��ʾ������Ŀǰ����ʾ�ͻ���<=>�������֤���̣����ע�����д���

	/*
	//	У��DLL
	int(*_main) (int, _TCHAR**) = _tmain;
	void(*_magic) (Order&, int) = Magic;
	int func_len = (unsigned int)_main - (unsigned int)_magic;

//	cout << func_len << endl;

	unsigned char szFuncBuff[1000];
	memcpy(szFuncBuff, (char*)_magic, func_len);
//	ShowHEXofBytes(szFuncBuff, func_len);

	typedef void(*fnMagic) (Order&, int);
	_magic = ((fnMagic)&szFuncBuff[0]);
	Order od;
	Magic(od, 11);
//	cout << od.nVolume << endl;

	unsigned char szFuncEncryptBuff[1000];
	size_t uEncryptCodeSize;
	Pobo::Security::OpenSSL_AES256_CBC_Encrypt(szFuncBuff, func_len, szFuncEncryptBuff, uEncryptCodeSize);
//	ShowHEXofBytes(szFuncEncryptBuff, uEncryptCodeSize);
//	cout << endl;
//	return 0;
	*/

	/*
	unsigned char szFuncEncryptBuff2[] = {
		0x1A, 0x7D, 0x24, 0x48, 0xA7, 0x22, 0xAE, 0x1A, 0x39, 0x61, 0xE6, 0x77, 0x9B, 0xA3, 0x6C, 0x84,
		0xF5, 0x70, 0x6C, 0xF1, 0x7E, 0x8A, 0x22, 0x2E, 0x04, 0xE8, 0x1A, 0xBA, 0x2D, 0x93, 0xCF, 0x03,
	};
	size_t uEncryptCodeSize = sizeof(szFuncEncryptBuff2);
//	cout << uEncryptCodeSize << endl;
	unsigned char szFuncBuff2[1000];
	size_t uCodeSize2 = sizeof(szFuncBuff2);
	if (Pobo::Security::GetResultB(szFuncEncryptBuff2, uEncryptCodeSize, szFuncBuff2, uCodeSize2))
		cout << "���ܳɹ�" << endl;
//	ShowHEXofBytes(szFuncBuff2, uCodeSize2);
	typedef void(*fnMagic) (Order&, int);
	fnMagic _magic2 = ((fnMagic)&szFuncBuff2[0]);
	Order od2;
	_magic2(od2, 11);
	cout << od2.nVolume << endl;
	*/

	return 0;
}
